<?php 

$lang["disponibilidades_amount"] = "Cantidad";
$lang["disponibilidades_amount_number"] = "Cantidad debe ser un numero";
$lang["disponibilidades_amount_required"] = "Cantidad es un campo obligatorio.";
$lang["disponibilidades_description"] = "Descripción";
$lang["disponibilidades_error_adding_updating"] = "Error al agregar/actualizar";
$lang["disponibilidades_id"] = "Id";
$lang["disponibilidades_info"] = "Información de la cancha";
$lang["disponibilidades_is_deleted"] = "Borrado";
$lang["disponibilidades_new"] = "Nueva Disponibilidad";
$lang["disponibilidades_no_disponibilidades_to_display"] = "No hay Disponibilidads para mostrar";
$lang["disponibilidades_none_selected"] = "No ha seleccionado ningúna cancha";
$lang["disponibilidades_one_or_multiple"] = "Disponibilidad(s)";
$lang["disponibilidades_successful_adding"] = "Disponibilidad agregada con éxito";
$lang["disponibilidades_successful_deleted"] = "Disponibilidad borrada con éxito";
$lang["disponibilidades_successful_updating"] = "Disponibilidad actualizada con éxito";
$lang["disponibilidades_total"] = "Total";
$lang["disponibilidades_update"] = "Actualizar Disponibilidad";
