<?php 

$lang["canchas_amount"] = "Cantidad";
$lang["canchas_amount_number"] = "Cantidad debe ser un numero";
$lang["canchas_amount_required"] = "Cantidad es un campo obligatorio.";
$lang["canchas_description"] = "Descripción";
$lang["canchas_error_adding_updating"] = "Error al agregar/actualizar";
$lang["canchas_id"] = "Id";
$lang["canchas_info"] = "Información de la cancha";
$lang["canchas_is_deleted"] = "Borrado";
$lang["canchas_new"] = "Nueva Cancha";
$lang["canchas_no_canchas_to_display"] = "No hay Canchas para mostrar";
$lang["canchas_none_selected"] = "No ha seleccionado ningúna cancha";
$lang["canchas_one_or_multiple"] = "Cancha(s)";
$lang["canchas_successful_adding"] = "Cancha agregada con éxito";
$lang["canchas_successful_deleted"] = "Cancha borrada con éxito";
$lang["canchas_successful_updating"] = "Cancha actualizada con éxito";
$lang["canchas_total"] = "Total";
$lang["canchas_update"] = "Actualizar Cancha";
$lang["canchas_nombre"] = "Nombre";
$lang["canchas_foto"] = "Fotografia Cancha";
$lang["canchas_referencia"] = "Referencia";
#carlosch
$lang["canchas_error_file_upload"] = "No fue posible subir el archivo adjunto";
$lang["canchas_confirm_delete"] = "¿Desea eliminar las canchas seleccionadas?"; 


