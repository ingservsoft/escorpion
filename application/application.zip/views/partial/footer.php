		</div>
	</div>

	<div id="footer">
		<div style="padding: 20px 0px; color:#FFF;">
			<strong>QuieroCancha POS, todos los derechos reservados · 
			<a href="https://www.QuieroCancha.com" target="_blank">www.QuieroCancha.com</a>  · 
  			Versión: <?php echo $this->config->item('application_version'); ?></strong>.
		</div>
	</div>
</body>
</html>
